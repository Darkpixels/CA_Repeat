from django.urls import path
from .views import NewsListView, NewsDetailView, ArticleCreateView, ArticleUpdateView, ArticleDeleteView

urlpatterns = [
    path('', NewsListView.as_view(), name='news'),
    ##path('article/<int:pk>/', ArticleDetailView.as_view(), name='article_detail'),
    path('article/<int:pk>/', NewsDetailView.as_view(), 
                    name='article_detail'),
    path('article/new/', ArticleCreateView.as_view(), name='article_new'),
    path('post/<int:pk>/edit/',ArticleUpdateView.as_view(), name='article_edit'),
    path('post/<int:pk>/delete/',ArticleDeleteView.as_view(), name='article_delete'),
]